import socket 
header =16
port=5060
server= socket.gethostbyname(socket.gethostname())
addr= (server,port)
format='utf-8'
disconnect_msg= "End"

client= socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect(addr)

def send(msg):
    message= msg.encode(format)
    msg_length= len(message)
    send_length = str(msg_length).encode(format)
    send_length+=b' '*(header-len(send_length))
    client.send(send_length)
    client.send(message)
    print(client.recv(2048).decode(format))
connected=True
while connected:
    input_msg= input("Please enter message:")
    if input_msg==disconnect_msg:
        connected=False
        send(disconnect_msg)
    else:
        send(input_msg)    
print(client.recv(2048).decode(format))