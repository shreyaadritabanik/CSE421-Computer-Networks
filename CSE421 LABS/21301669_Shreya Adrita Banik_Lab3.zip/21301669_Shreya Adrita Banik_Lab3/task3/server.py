import socket 
import threading
header=16
port=5060
server= socket.gethostbyname(socket.gethostname())
addr= (server,port)
format='utf-8'
disconnect_msg= "End"

server= socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind(addr)


def handle_clients(conn,addr):
    connected  = True
    while connected:
        msg_len= conn.recv(header).decode(format)
        if msg_len:
            msg_len= int(msg_len)
            msg=conn.recv(msg_len).decode(format)
            if msg== disconnect_msg:
                connected= False
                print(f"Closing connection with {addr}")
                conn.send("Goodbye".encode(format))
            else:
                vowels= "aeiouAEIOU"
                count =0
                for i in msg:
                    if i in vowels:
                        count+=1
                if count==0:
                    conn.send("Not enough vowels".encode(format))
                elif count<=2:
                    conn.send("Enough vowels I guess".encode(format))
                else:
                    conn.send("Too many vowels".encode(format))
            
    conn.close()

def start():
    server.listen()
    print("Server is listening")
    while True:
        conn, addr=server.accept()
        thread= threading.Thread(target=handle_clients,args=(conn,addr))
        thread.start()
        print(f"Total clients connected:{threading.active_count()}")
start()


