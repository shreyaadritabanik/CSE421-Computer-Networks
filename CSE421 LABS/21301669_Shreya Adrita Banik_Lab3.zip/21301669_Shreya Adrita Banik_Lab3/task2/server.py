import socket 
header=16
port=5060
server= socket.gethostbyname(socket.gethostname())
addr= (server,port)
format='utf-8'
disconnect_msg= "End"

server= socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind(addr)
server.listen()
print("Server is listening")
conn, addr= server.accept()
connected= True

while connected:
    msg_len= conn.recv(header).decode(format)
    if msg_len:
        msg_len= int(msg_len)
        msg=conn.recv(msg_len).decode(format)
        if msg== disconnect_msg:
            connected= False
            print(f"Closing connection with {addr}")
            conn.send("Goodbye".encode(format))
        else:
            vowels= "aeiouAEIOU"
            count =0
            for i in msg:
                if i in vowels:
                    count+=1
            if count==0:
                conn.send("Not enough vowels".encode(format))
            elif count<=2:
                conn.send("Enough vowels I guess".encode(format))
            else:
                conn.send("Too many vowels".encode(format))
            
conn.close()


