import socket 
header=16
port=5060
server= socket.gethostbyname(socket.gethostname())
addr= (server,port)
format='utf-8'
disconnect_msg= "End"

server= socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind(addr)
server.listen()
print("Server is listening")
conn, addr= server.accept()
connected= True
while connected:
    msg_len= conn.recv(header).decode(format)
    if msg_len:
        msg_len=int(msg_len)
        msg=conn.recv(msg_len).decode(format)
        if msg==disconnect_msg:
            print(f"Closing connection with {addr}")
            conn.send("Goodbye".encode(format))
            connected = False
        else:
            if int(msg)<= 40:
                salary = int(msg)* 200
                print("Salary is:", salary)
                conn.send (f"Salary is {salary}".encode('utf-8'))
            else:
                salary =8000 + 300*(int(msg)-40)
                print("Salary is:", salary)
                conn.send (f"Salary is {salary}".encode('utf-8'))
           
conn.close()
