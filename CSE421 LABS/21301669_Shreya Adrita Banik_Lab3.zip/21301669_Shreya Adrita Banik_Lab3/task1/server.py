import socket 
header=16
port=5060
server= socket.gethostbyname(socket.gethostname())
addr= (server,port)
format='utf-8'
disconnect_msg= "End"

server= socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind(addr)
server.listen()
print("Server is listening")
conn, addr= server.accept()
connected= True

while connected:
    msg_len= conn.recv(header).decode(format)
    if msg_len:
        msg_len= int(msg_len)
        msg=conn.recv(msg_len).decode(format)
        if msg== disconnect_msg:
            connected= False
            print(f"Closing connection with {addr}")
            conn.send("Goodbye".encode(format))
        else:
            print(msg)
            conn.send("Message Received".encode(format))
conn.close()


